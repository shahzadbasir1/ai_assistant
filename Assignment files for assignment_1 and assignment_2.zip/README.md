# 🤖 AI Business Assistant

An AI-powered business assistant that performs key business tasks using natural language input. This project leverages OpenAI’s function-calling capabilities to intelligently route user queries to the appropriate tools.

---

## 🚀 Features

This assistant supports the following business capabilities:

### 📧 1. Smart Email Writer

* Generates professional emails
* Supports tone customization (formal, friendly, professional)
* Can include real-time market research

### 📊 2. Report Generator

* Creates structured business reports from data
* Calculates key metrics (total, average, max)
* Provides insights and recommendations

### 📝 3. Meeting Summarizer

* Converts raw meeting notes into structured summaries
* Extracts key points, decisions, and action items

### 📈 4. Data Analyzer

* Performs calculations on business data
* Supports:

  * Sum
  * Average
  * Max / Min
* Accepts both lists and dictionary inputs

### 🤝 5. Client Communication Drafter

* Generates professional client communications:

  * Proposals
  * Status updates
  * Follow-ups

---

## 🧠 How It Works

The system uses an AI routing architecture:

User Input → OpenAI → Tool Selection → Function Execution → Response

* The OpenAI model determines which tool to call
* The corresponding function is executed
* The result is returned to the model for a final response

---

## 📁 Project Structure

```
project/
│
├── ai_business_assistant.py   # Main application (AI routing)
├── tools.py                   # Tool functions and definitions
├── .env                       # API keys (not committed)
├── README.md                  # Project documentation
```

---

## ⚙️ Installation

### 1. Clone the repository

```
git clone <your-repo-url>
cd project
```

### 2. Create and activate virtual environment

```
python -m venv venv
venv\Scripts\activate   # Windows
```

### 3. Install dependencies

```
pip install openai requests python-dotenv
```

---

## 🔑 Environment Variables

Create a `.env` file in the root directory:

```
OPENAI_API_KEY=your_openai_api_key
SERPAPI_KEY=your_serpapi_key
```

---

## ▶️ Running the Application

```
python ai_business_assistant.py
```

---

## 🧪 Example Prompts

### 📧 Email Writing

```
Write an email to stakeholders announcing Q2 sales results with a formal tone and include market trends in AI
```

### 📊 Report Generation

```
Generate a quarterly sales report for {"Jan": 50000, "Feb": 65000, "Mar": 70000} for Q1 2026
```

### 📝 Meeting Summary

```
Summarize meeting:
Discussed marketing plan. Budget approved. Ahmed will lead. Need 2 hires.
```

### 📈 Data Analysis

```
Find the average of [50000, 60000, 70000]
```

### 🤝 Client Communication

```
Draft a project proposal for ABC Technologies for a website redesign with a 3-month timeline and $50k budget
```

---

## ⚠️ Notes & Limitations

* Uses `eval()` for calculations (safe in controlled input, not recommended for production)
* Web search depends on SerpAPI (requires API key)
* Tool selection depends on LLM accuracy (may occasionally misroute)

---

## 🚀 Future Enhancements

* Add conversation memory
* Improve parameter extraction
* Add multi-step workflows (e.g., report + email)
* Build UI using Streamlit
* Replace mock/limited logic with real business intelligence

---

## 👨‍💻 Author

Shahzad Basir
AI / Data Science Enthusiast

---

## 📌 License

This project is for educational and portfolio purposes.
