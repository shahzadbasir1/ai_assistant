import os
import json
from dotenv import load_dotenv
from openai import OpenAI

# Import from tools.py
from tools import tools, function_map

# Load environment variables
load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


# =========================
# AI ROUTER
# =========================

def process_query(user_input):

    # First call → let AI decide tool
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": "You are a business assistant. Use tools when needed."
            },
            {
                "role": "user",
                "content": user_input
            }
        ],
        tools=tools,
        tool_choice="auto"
    )

    message = response.choices[0].message

    # =========================
    # TOOL CALL HANDLING
    # =========================

    if message.tool_calls:
        tool_call = message.tool_calls[0]

        function_name = tool_call.function.name
        arguments = json.loads(tool_call.function.arguments)

        print(f"\n[DEBUG] Tool Called: {function_name}")
        print(f"[DEBUG] Arguments: {arguments}")

        # Execute function from tools.py
        result = function_map[function_name](**arguments)

        print(f"[DEBUG] Tool Result: {result}")

        # Second call → send tool result back to AI
        final_response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {
                    "role": "system",
                    "content": "You are a helpful business assistant."
                },
                {
                    "role": "user",
                    "content": user_input
                },
                {
                    "role": "assistant",
                    "tool_calls": [tool_call]
                },
                {
                    "role": "tool",
                    "tool_call_id": tool_call.id,
                    "content": result
                }
            ]
        )

        return final_response.choices[0].message.content

    # =========================
    # NO TOOL NEEDED
    # =========================

    else:
        return message.content


# =========================
# MAIN LOOP
# =========================

def main():
    print("🤖 AI Business Assistant (Type 'exit' to quit)\n")

    while True:
        user_input = input("You: ")

        if user_input.lower() == "exit":
            print("Goodbye!")
            break

        try:
            response = process_query(user_input)
            print("\nAssistant:", response)

        except Exception as e:
            print("\n[ERROR]:", str(e))


# =========================
# RUN
# =========================

if __name__ == "__main__":
    main()