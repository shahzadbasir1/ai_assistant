from tools import (
    calculate,
    web_search,
    analyze_data,
    write_email,
    generate_report,
    summarize_meeting,
    draft_client_communication
)

def test_calculate():
    print("TEST: Calculate")
    print(calculate("25 * 4 + 10"))

def test_web_search():
    print("\nTEST: Web Search")
    print(web_search("latest AI market trends"))

def test_analyze_data():
    print("\nTEST: Analyze Data")
data = "[50000, 60000, 70000]"
print(analyze_data(data, "average"))

def test_write_email():
    print("\nTEST: Write Email")
    print(write_email(
    purpose="Announce Q2 results",
    recipient="Stakeholders",
    tone="formal",
    research_topic="AI market trends"
))

def test_generate_report():
    print("\nTEST: Generate Report")
    data = '{"Jan": 50000, "Feb": 60000, "Mar": 70000}'
    print(generate_report("sales", data, "Q1 2026"))

def test_summarize_meeting():
    print("\nTEST: Summarize Meeting")
    notes = "Discussed Q2 marketing. Budget approved. Ahmed will lead. Need 2 hires."
    print(summarize_meeting(notes, "May 3, 2026", "Team Members"))

def test_client_communication():
    print("\nTEST: Client Communication")
    print(draft_client_communication(
    comm_type="Project Proposal",
    client="ABC Technologies",
    context="Website redesign project with 3-month timeline and $50k budget",
    tone="professional"
))

    if **name** == "**main**":
        print("🚀 Running Feature Tests...\n")

    ```
    test_calculate()
    test_web_search()
    test_analyze_data()
    test_write_email()
    test_generate_report()
    test_summarize_meeting()
    test_client_communication()

    print("\n✅ All tests completed.")
    ```
